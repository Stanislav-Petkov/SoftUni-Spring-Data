create definer = root@localhost view v_name_salaries as
select `hospital`.`employees`.`id`                                                          AS `id`,
       concat(`hospital`.`employees`.`first_name`, ' ', `hospital`.`employees`.`last_name`) AS `Full name`,
       `hospital`.`employees`.`salary`                                                      AS `salaries`
from `hospital`.`employees`;


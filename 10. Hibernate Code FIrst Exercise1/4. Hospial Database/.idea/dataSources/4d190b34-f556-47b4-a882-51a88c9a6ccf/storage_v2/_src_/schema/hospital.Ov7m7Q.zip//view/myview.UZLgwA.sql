create definer = root@localhost view myview as
select `hospital`.`employees2`.`first_name` AS `first_name`, 5 AS `5`
from `hospital`.`employees2`
order by `hospital`.`employees2`.`salary` desc, `hospital`.`employees2`.`first_name`,
         `hospital`.`employees2`.`last_name` desc;


create definer = root@localhost view hr_view as
select concat_ws(' - ', `hospital`.`employees2`.`first_name`, `hospital`.`employees2`.`last_name`) AS `full_name`,
       `hospital`.`employees2`.`salary`                                                            AS `salary`
from `hospital`.`employees2`;

